let estado = "off"; // off = parado, on = ativo

// --- Classe Jogador ---
class Jogador {
    constructor(velocidade = 5) {
        this.velocidade = velocidade;
        this.tamanho = 0;
        this.posicao = { x: 100, y: 100 };
        this.direcao = null;
        this.vida = true;
    }

    mover() {
        if (!this.direcao || !this.vida) return;
        if (this.direcao === "up") this.posicao.y -= this.velocidade;
        if (this.direcao === "down") this.posicao.y += this.velocidade;
        if (this.direcao === "left") this.posicao.x -= this.velocidade;
        if (this.direcao === "right") this.posicao.x += this.velocidade;
    }
}

const jogador = new Jogador();
const divJogador = document.getElementById("jogador");
const infoDiv = document.getElementById("info");

// --- Bolinha ---
let bolinha = null;

function criarBolinha() {
    if (bolinha) bolinha.remove();

    bolinha = document.createElement("div");
    bolinha.classList.add("bolinha");
    bolinha.style.width = "25px";
    bolinha.style.height = "25px";
    bolinha.style.backgroundColor = "orange";
    bolinha.style.position = "absolute";
    bolinha.style.borderRadius = "50%";

    // Aparece em posição aleatória
    bolinha.style.left = Math.random() * (window.innerWidth - 25) + "px";
    bolinha.style.top = Math.random() * (window.innerHeight - 25) + "px";

    document.body.appendChild(bolinha);
}

// --- Atualização da tela ---
function atualizarTela() {
    divJogador.style.left = jogador.posicao.x + "px";
    divJogador.style.top = jogador.posicao.y + "px";
}

// --- Colisão com bordas ---
function checarColisaoBordas() {
    if (
        jogador.posicao.x < 0 ||
        jogador.posicao.y < 0 ||
        jogador.posicao.x + 50 + jogador.tamanho > window.innerWidth ||
        jogador.posicao.y + 50 + jogador.tamanho > window.innerHeight
    ) {
        jogador.vida = false;
        estado = "off";
        infoDiv.innerHTML = "<strong>💀 Você bateu na borda!</strong><br>Pressione F5 para reiniciar.";
    }
}

// --- Colisão com bolinha ---
function checarColisaoBolinha() {
    if (!bolinha) return;

    const jogadorRect = divJogador.getBoundingClientRect();
    const bolaRect = bolinha.getBoundingClientRect();

    if (
        jogadorRect.left < bolaRect.right &&
        jogadorRect.right > bolaRect.left &&
        jogadorRect.top < bolaRect.bottom &&
        jogadorRect.bottom > bolaRect.top
    ) {
        jogador.tamanho++;
        divJogador.style.width = 50 + jogador.tamanho + "px";
        divJogador.style.height = 50 + jogador.tamanho + "px";

        // Se tamanho passar de 48, vai para créditos
        if (jogador.tamanho > 48) {
            window.location.href = "creditos/creditos.html";
            return;
        }

        criarBolinha(); // Cria nova bolinha
    }
}

// --- Loop principal ---
function loop() {
    if (estado === "on" && jogador.vida) {
        jogador.mover();
        atualizarTela();
        checarColisaoBolinha();
        checarColisaoBordas();
    }
    requestAnimationFrame(loop);
}

// --- Controles ---
document.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && estado === "off" && jogador.vida) {
        estado = "on";
        jogador.direcao = "right";
        criarBolinha();
    }

    if (estado === "on" && jogador.vida) {
        const dir = jogador.direcao;
        if (event.key === "ArrowUp" && dir !== "down") jogador.direcao = "up";
        if (event.key === "ArrowDown" && dir !== "up") jogador.direcao = "down";
        if (event.key === "ArrowLeft" && dir !== "right") jogador.direcao = "left";
        if (event.key === "ArrowRight" && dir !== "left") jogador.direcao = "right";
    }
});

loop();
