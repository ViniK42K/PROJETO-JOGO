let estado = "off"; // off = parado, on = ativo
let palavraAtual = null;

// --- Classe Palavra ---
class Palavra {
    constructor(texto, significado) {
        this.texto = texto;
        this.letras = texto.split("");
        this.significado = significado;
    }
}

const palavras = [
    new Palavra('banana', 'Uma fruta amarela e doce que se come fácil.'),
    new Palavra('abacaxi', 'Uma fruta grande, com casca dura e doce por dentro.'),
    new Palavra('amarelo', 'A cor do sol e da banana.'),
    new Palavra('tomate', 'Uma fruta vermelha que se usa na comida.'),
    new Palavra('sapato', 'O que usamos nos pés para andar.'),
    new Palavra('telefone', 'Um aparelho que usamos para falar com alguém longe.'),
    new Palavra('elefante', 'Um animal muito grande com tromba e orelhas grandes.'),
    new Palavra('caderno', 'Um caderno para escrever e desenhar.'),
    new Palavra('janela', 'A abertura na parede por onde entra luz e ar.'),
    new Palavra('boneca', 'Um brinquedo que parece uma pessoa pequena.'),
    new Palavra('pipoca', 'Milho que estoura no fogo e fica gostoso para comer.'),
    new Palavra('bicicleta', 'Um veículo de duas rodas que se pedala para andar.'),
    new Palavra('chuveiro', 'O lugar onde a água cai para tomar banho.'),
    new Palavra('abajur', 'Uma luz que fica em cima da mesa para iluminar.'),
    new Palavra('chocolate', 'Doce feito de cacau, muito gostoso de comer.')
];

// --- Classe Jogador ---
class Jogador {
    constructor(velocidade = 0) {
        this.velocidade = velocidade;
        this.tamanho = 0;
        this.posicao = { x: 0, y: 0 };
        this.direcao = null;
        this.fase = 1;
        this.pontuacao = 0;
        this.vida = true;
    }

    mover() {
        if (!this.direcao || !this.vida) return;
        if (this.direcao === "up") this.posicao.y -= this.velocidade;
        if (this.direcao === "down") this.posicao.y += this.velocidade;
        if (this.direcao === "left") this.posicao.x -= this.velocidade;
        if (this.direcao === "right") this.posicao.x += this.velocidade;
    }
}

// --- Classe Fase ---
class Fase {
    constructor(numero, bolinhasLaranja = [], bolinhasVerde = [], bolinhasRoxa = []) {
        this.numero = numero;
        this.bolinhasLaranja = bolinhasLaranja;
        this.bolinhasVerde = bolinhasVerde;
        this.bolinhasRoxa = bolinhasRoxa;
    }
}

// --- Fases ---
const fases = [
    new Fase(1, [], [], []),
    new Fase(2, [], [{ x: 50, y: 350 }], [{ x: 700, y: 100 }]),
    new Fase(3, [{ x: 400, y: 250 }], [{ x: 50, y: 250 }], [{ x: 750, y: 250 }]),
    new Fase(4, [{ x: 100, y: 150 }, { x: 400, y: 150 }], [{ x: 150, y: 250 }], [{ x: 250, y: 300 }]),
    new Fase(5, [{ x: 80, y: 100 }, { x: 250, y: 200 }], [{ x: 150, y: 150 }], [{ x: 100, y: 200 }])
];

// --- Mensagens por fase ---
const mensagensFase = {
    1: "Fase 1: Preciso comer para crescer. Evite a parede!",
    2: "Fase 2: Cuidado com o veneno e pegue a poção verde para aumentar velocidade!",
    3: "Fase 3: Atenção! Evite a bomba!",
    4: "Fase 4: Está escuro. Tome cuidado e siga pelo campo de visão!",
    5: "Fase 5: Obstáculos pelo caminho. Movimente-se com cuidado!"
};

const jogador = new Jogador();
const divJogador = document.getElementById("jogador");
const infoDiv = document.getElementById("info");

let seguidores = [];
let history = [];

// --- Atualização da tela ---
function atualizarTela() {
    divJogador.style.left = jogador.posicao.x + "px";
    divJogador.style.top = jogador.posicao.y + "px";
}

// --- Colisões ---
function checarColisoes() {
    const jogadorRect = divJogador.getBoundingClientRect();
    const botoes = document.querySelectorAll('button:not(#controls button)');

    botoes.forEach(botao => {
        const botaoRect = botao.getBoundingClientRect();
        if (
            jogadorRect.left < botaoRect.right &&
            jogadorRect.right > botaoRect.left &&
            jogadorRect.top < botaoRect.bottom &&
            jogadorRect.bottom > botaoRect.top
        ) {
            jogador.tamanho++;
            document.getElementById('tamanho').textContent = 'Cliques: ' + jogador.tamanho;
            botao.remove();
            criarSeguidor();
            if (palavraAtual) pontuacao(palavraAtual);
        }
    });

    seguidores.forEach(seg => {
        const segRect = seg.getBoundingClientRect();
        if (
            jogadorRect.left < segRect.right &&
            jogadorRect.right > segRect.left &&
            jogadorRect.top < segRect.bottom &&
            jogadorRect.bottom > segRect.top
        ) {
            jogador.vida = false;
            estado = "off";
            infoDiv.innerHTML = "<strong>Você morreu!</strong><br>Pressione F5 para reiniciar.";
            autoSalvar();
        }
    });
}

// --- Seguidores ---
function criarSeguidor() {
    const seg = document.createElement("div");
    seg.classList.add("seguidor");
    document.body.appendChild(seg);
    seguidores.push(seg);
}

// --- Bolinhas ---
function criarBolinhasDaFase(fase) {
    document.querySelectorAll(".bolinha").forEach(b => b.remove());
    fase.bolinhasLaranja.forEach(pos => criarBolinha(pos, "laranja"));
    fase.bolinhasVerde.forEach(pos => criarBolinha(pos, "verde"));
    fase.bolinhasRoxa.forEach(pos => criarBolinha(pos, "roxa"));
}

function criarBolinha(pos, cor) {
    const bola = document.createElement("div");
    bola.classList.add("bolinha", cor);
    bola.style.left = pos.x + "px";
    bola.style.top = pos.y + "px";
    bola.style.width = "25px";
    bola.style.height = "25px";
    bola.dataset.grande = "false";
    document.body.appendChild(bola);

    const ciclo = async () => {
        while (true) {
            bola.dataset.grande = "false";
            bola.style.transform = "scale(1)";
            bola.style.opacity = "1";
            await esperar(2000);

            bola.dataset.grande = "true";
            bola.style.transform = "scale(3.5)";
            bola.style.transition = "transform 0.8s ease";
            await esperar(5000);

            bola.style.opacity = "0";
            await esperar(1000);

            bola.style.opacity = "1";
            bola.dataset.grande = "false";
            bola.style.transform = "scale(1)";
            bola.style.left = Math.random() * (window.innerWidth - 50) + "px";
            bola.style.top = Math.random() * (window.innerHeight - 50) + "px";
        }
    };
    ciclo();
}

let ultimaColisao = 0;

function checarColisaoBolinhas() {
    const agora = Date.now();
    if (agora - ultimaColisao < 2000) return;

    const jogadorRect = divJogador.getBoundingClientRect();
    document.querySelectorAll(".bolinha").forEach(bola => {
        const bolaRect = bola.getBoundingClientRect();
        const grande = bola.dataset.grande === "true";

        if (
            grande &&
            jogadorRect.left < bolaRect.right &&
            jogadorRect.right > bolaRect.left &&
            jogadorRect.top < bolaRect.bottom &&
            jogadorRect.bottom > bolaRect.top
        ) {
            ultimaColisao = agora;

            if (bola.classList.contains("laranja")) {
                jogador.vida = false;
                estado = "off";
                infoDiv.innerHTML = "<strong>💥 Você foi atingido pela bomba laranja!</strong>";
            } else if (bola.classList.contains("verde")) {
                jogador.velocidade += 0.2;
                infoDiv.innerHTML = "<strong>⚡ Velocidade ligeiramente aumentada!</strong>";
                setTimeout(() => jogador.velocidade -= 0.2, 4000);
            } else if (bola.classList.contains("roxa")) {
                jogador.velocidade = Math.max(0.5, jogador.velocidade - 0.2);
                infoDiv.innerHTML = "<strong>🐢 Velocidade ligeiramente reduzida!</strong>";
                setTimeout(() => jogador.velocidade += 0.2, 4000);
            }
        }
    });
}

function checarColisaoBordas() {
    if (
        jogador.posicao.x < 0 ||
        jogador.posicao.y < 0 ||
        jogador.posicao.x + 50 + jogador.tamanho > window.innerWidth ||
        jogador.posicao.y + 50 + jogador.tamanho > window.innerHeight
    ) {
        jogador.vida = false;
        estado = "off";
        infoDiv.innerHTML = "<strong>💀 Você bateu na borda!</strong><br>Pressione F5 para reiniciar.";
    }
}

// --- Utilitário ---
function esperar(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// --- Sombra e campo de visão ---
let sombraDiv = null;
let campoVisaoDiv = null;

function ativarSombraEFoco() {
    if (!sombraDiv) {
        sombraDiv = document.createElement("div");
        sombraDiv.style.position = "fixed";
        sombraDiv.style.top = "0";
        sombraDiv.style.left = "0";
        sombraDiv.style.width = "100vw";
        sombraDiv.style.height = "100vh";
        sombraDiv.style.background = "rgba(0,0,0,0.95)";
        sombraDiv.style.pointerEvents = "none";
        sombraDiv.style.zIndex = "9999";
        document.body.appendChild(sombraDiv);
    }

    if (!campoVisaoDiv) {
        campoVisaoDiv = document.createElement("div");
        campoVisaoDiv.style.position = "absolute";
        campoVisaoDiv.style.width = "250px";
        campoVisaoDiv.style.height = "250px";
        campoVisaoDiv.style.borderRadius = "50%";
        campoVisaoDiv.style.boxShadow = "0 0 0 9999px rgba(0,0,0,0.85)";
        campoVisaoDiv.style.pointerEvents = "none";
        campoVisaoDiv.style.zIndex = "10000";
        document.body.appendChild(campoVisaoDiv);
    }

    infoDiv.style.position = "fixed";
    infoDiv.style.zIndex = "10001";
}

function atualizarCampoVisao() {
    if (campoVisaoDiv) {
        campoVisaoDiv.style.left = jogador.posicao.x + 25 - 125 + "px";
        campoVisaoDiv.style.top = jogador.posicao.y + 25 - 125 + "px";
    }
}

// --- Loop principal ---
function loop() {
    if (estado === "on" && jogador.vida) {
        jogador.mover();
        atualizarTela();
        checarColisoes();
        checarColisaoBolinhas();
        checarColisaoBordas();

        if (jogador.fase === 4) {
            ativarSombraEFoco();
            atualizarCampoVisao();
        } else {
            if (sombraDiv) { sombraDiv.remove(); sombraDiv = null; }
            if (campoVisaoDiv) { campoVisaoDiv.remove(); campoVisaoDiv = null; }
        }
    }

    history.push({ x: jogador.posicao.x, y: jogador.posicao.y });
    if (history.length > 1000) history.shift();

    seguidores.forEach((seg, index) => {
        let delay = (index + 1) * 20;
        if (history.length > delay) {
            let pos = history[history.length - delay];
            seg.style.left = pos.x + "px";
            seg.style.top = pos.y + "px";
        }
    });

    requestAnimationFrame(loop);
}
loop();

// --- Avançar de fase ---
function avancarFase() {
    jogador.fase++;

    if (jogador.fase >= 6) {
        jogador.fase = 1;
        infoDiv.innerHTML = `<strong>🎉 Você completou todas as fases!</strong><br>Voltando para a fase 1...`;
    } else {
        infoDiv.innerHTML = `<strong>🎉 Você ganhou a fase ${jogador.fase - 1}!</strong><br>Agora você está na fase ${jogador.fase}.`;
    }

    jogador.pontuacao = 0;
    estado = "off";
    autoSalvar();
    setTimeout(() => location.reload(), 3000);
}

// --- Pontuação ---
function pontuacao(palavraAtual) {
    if (jogador.tamanho === palavraAtual.letras.length) {
        jogador.pontuacao++;
        jogador.tamanho = 0;
        infoDiv.innerHTML = `<strong>Palavra completa!</strong><br>Pontuação: ${jogador.pontuacao}`;

        if (jogador.pontuacao >= 3) {
            avancarFase();
        } else {
            gerarPalavraEFase();
            autoSalvar();
        }
    }
}

// --- Palavra e fase ---
function gerarPalavraEFase() {
    if (estado === "off" || !jogador.vida) return;

    document.querySelectorAll('button:not(#controls button)').forEach(b => b.remove());

    if (jogador.fase <= fases.length) {
        // Mostra mensagem da fase
        infoDiv.innerHTML = `<strong>${mensagensFase[jogador.fase]}</strong>`;

        setTimeout(() => {
            criarBolinhasDaFase(fases[jogador.fase - 1]);

            const index = Math.floor(Math.random() * palavras.length);
            const palavra = palavras[index];
            palavraAtual = palavra;

            infoDiv.innerHTML = `<strong>${palavra.texto.toUpperCase()}</strong><br><span>${palavra.significado}</span><br><br>Pontuação: ${jogador.pontuacao} | Fase: ${jogador.fase}`;

            const bodyWidth = window.innerWidth;
            const bodyHeight = window.innerHeight;

            palavra.letras.forEach(letra => {
                const botao = document.createElement('button');
                botao.textContent = letra;
                botao.style.left = Math.random() * (bodyWidth - 60) + 'px';
                botao.style.top = 50 + Math.random() * (bodyHeight - 60 - 50) + 'px';
                document.body.appendChild(botao);
            });
        }, 2000);
    } else resetarSite();
}

// --- JSON ---
function salvarJSON() {
    localStorage.setItem("progressoJogo", JSON.stringify({
        fase: jogador.fase,
        pontuacao: jogador.pontuacao,
        vida: jogador.vida,
        data: new Date().toLocaleString()
    }));
}

function carregarJSON() {
    const dados = JSON.parse(localStorage.getItem("progressoJogo") || "{}");
    if (dados) {
        jogador.fase = dados.fase || 1;
        jogador.pontuacao = dados.pontuacao || 0;
        jogador.vida = true;
        infoDiv.innerHTML = `<strong>Progresso carregado!</strong><br>Fase: ${jogador.fase}<br>Pontuação: ${jogador.pontuacao}`;
    }
}

function limparJSON() {
    localStorage.removeItem("progressoJogo");
    infoDiv.innerHTML = `<strong>Progresso apagado!</strong><br>Pressione F5 para começar de novo.`;
}

function autoSalvar() {
    salvarJSON();
}

// --- Reset de fase e verificação ---
window.onload = () => {
    carregarJSON();
    if (jogador.fase >= 6) {
        jogador.fase = 1;
        jogador.pontuacao = 0;
        autoSalvar();
        infoDiv.innerHTML = `<strong>🎉 Você completou todas as fases!</strong><br>Voltando para a fase 1...`;
    }
}

// --- Controles ---
document.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && estado === "off" && jogador.vida) {
        estado = "on";
        jogador.velocidade = 5;
        jogador.direcao = "right";
        gerarPalavraEFase();
    }

    if (estado === "on" && jogador.vida) {
        const dir = jogador.direcao;
        if (event.key === "ArrowUp" && dir !== "down") jogador.direcao = "up";
        if (event.key === "ArrowDown" && dir !== "up") jogador.direcao = "down";
        if (event.key === "ArrowLeft" && dir !== "right") jogador.direcao = "left";
        if (event.key === "ArrowRight" && dir !== "left") jogador.direcao = "right";
    }

    if (event.key === "r" || event.key === "R") limparJSON();
});

// --- Reset final ---
function resetarSite() {
    infoDiv.innerHTML = `<strong>Jogo concluído!</strong><br>Salvando progresso...`;
    autoSalvar();
    setTimeout(() => location.reload(), 3000);
}
